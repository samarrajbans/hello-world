<?php
/*
	Plugin Name: SEO Service Merchant
	Plugin URI:http://seoservices.ng
	Description: Dashboard for site specific Merchants under SEO Services
	Author:seoservices
	Author URI: http://seoservices.ng
	Version: 1.0.0	
*/

//Block direct access to your plugin PHP files
defined( 'ABSPATH' ) or die( 'No script kiddies please!' );
	

global $ds_mss_version;
global $ds_ss_load_css;
$ds_ss_load_css =  false;
$ds_mss_version = '1.0.0';

// create required tables with default data
register_activation_hook(__FILE__,'ds_mss_install');

// activation hook callback for handling database creation
function ds_mss_install() 
{
	global $wpdb;
	global $ds_mss_version; // to keep track of plugin version
	
	//Newsletter table definition 
	$mss_country_table  =  $wpdb->prefix."country";
	
	$mss_country_table_sql = "CREATE TABLE IF NOT EXISTS ".$mss_country_table." (
		`country_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
		`country_code` varchar(2) NOT NULL DEFAULT '',
		`country_name` varchar(100) NOT NULL DEFAULT '',
		PRIMARY KEY (`country_id`)
	)";
	
	$mss_project_table  = $wpdb->prefix."projects";
	$mss_project_table_sql = "CREATE TABLE IF NOT EXISTS ".$mss_project_table." (
		 `project_id` int(11) NOT NULL AUTO_INCREMENT,
		 `user_id` int(11) NOT NULL,
		 `project_name` varchar(255) NOT NULL DEFAULT '',
		 `company_name` varchar(255) NOT NULL DEFAULT '',
		 `project_url` varchar(255) NOT NULL DEFAULT '',
		 `description` text NOT NULL,
		 `project_status` tinyint(4) NOT NULL DEFAULT '1',
		 `created` datetime NOT NULL,
		 `updated` datetime NOT NULL,
		 PRIMARY KEY (`project_id`)
	)";
	
	$mss_packages_table  = $wpdb->prefix."packages";	
	$mss_packages_table_sql = "CREATE TABLE IF NOT EXISTS ".$mss_packages_table." (
		 `package_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
		 `user_id` int(11) NOT NULL,
		 `project_id` int(11) NOT NULL,
		 `package_name` varchar(255) NOT NULL,
		 `description` text NOT NULL,
		 `price` int(11) NOT NULL DEFAULT '0',
		 `duration` tinyint(3) NOT NULL DEFAULT '3',
		 `status` tinyint(3) NOT NULL DEFAULT '0',
		 `created` datetime NOT NULL,
		 `updated` datetime NOT NULL,
		 PRIMARY KEY (`package_id`)
	)";
	
	$mss_country_defaults_sql = "INSERT INTO ".$mss_country_table." (`country_id`, `country_code`, `country_name`) VALUES
							(1,	'AF',	'Afghanistan'),
							(2,	'AL',	'Albania'),
							(3,	'DZ',	'Algeria'),
							(4,	'DS',	'American Samoa'),
							(5,	'AD',	'Andorra'),
							(6,	'AO',	'Angola'),
							(7,	'AI',	'Anguilla'),
							(8,	'AQ',	'Antarctica'),
							(9,	'AG',	'Antigua and Barbuda'),
							(10,	'AR',	'Argentina')
						";
	
	
	
	require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
	dbDelta($mss_country_table_sql);
	dbDelta($mss_project_table_sql);
	dbDelta($mss_packages_table_sql);
	dbDelta($mss_country_defaults_sql);
	//add_option('ds_mss_version',$ds_mss_version);
	
}


// deactivation hook call back
function int_forms_uninstall() {
	global $wpdb;
	global $ds_mss_version; // to keep track of plugin version
	$mss_country_table  =  $wpdb->prefix."country";

	//$wpdb->query("DROP TABLE IF EXISTS ".$mss_country_table);
	// else do nothing
}


//merchant signup  


function mss_signup( $username, $first_name = '', $last_name = '', $email, $password,  $website = '', $phone = '' , $address1 = '' ,$address2 = '',$city = '',$region = '',$postcode = '',$country = '' ) {
    echo '
    <style>
    div {
        margin-bottom:2px;
    }
     
    input{
        margin-bottom:4px;
    }
    </style>
    ';
	global $ds_ss_load_css; 
	$ds_ss_load_css = true;
    echo '<div class="mss_forms">
    <form action="' . $_SERVER['REQUEST_URI'] . '" method="post" id="" name="" >
	<div>
    <label for="username">Username <strong>*</strong></label>
    <input type="text" name="username" value="' . ( isset( $_POST['username'] ) ? $username : null ) . '">
    </div>
     
	<div>
    <label for="firstname">First Name</label>
    <input type="text" name="fname" value="' . ( isset( $_POST['fname']) ? $first_name : null ) . '">
    </div>
     
    <div>
    <label for="website">Last Name</label>
    <input type="text" name="lname" value="' . ( isset( $_POST['lname']) ? $last_name : null ) . '">
    </div>
	<div>
    <label for="email">Email <strong>*</strong></label>
    <input type="text" name="email" value="' . ( isset( $_POST['email']) ? $email : null ) . '">
    </div>
     <div>
    <label for="password">Password <strong>*</strong></label>
    <input type="password" name="password" value="' . ( isset( $_POST['password'] ) ? $password : null ) . '">
    </div>
    <div>
    <label for="website">Website/Company</label>
    <input type="text" name="website" value="' . ( isset( $_POST['website']) ? $website : null ) . '">
    </div>
    <div>
    <label for="website">Mobile/Phone</label>
    <input type="text" name="phone" value="' . ( isset( $_POST['phone']) ? $phone : null ) . '">
    </div> 
	<div>
    <label for="website">Address 1</label>
    <input type="text" name="address1" value="' . ( isset( $_POST['address1']) ? $address1 : null ) . '">
    </div>
	<div>
    <label for="website">Address 2</label>
    <input type="text" name="address2" value="' . ( isset( $_POST['address2']) ? $address2 : null ) . '">
    </div>
     <div>
    <label for="website">City</label>
    <input type="text" name="city" value="' . ( isset( $_POST['city']) ? $city : null ) . '">
    </div>
	<div>
    <label for="website">Region</label>
    <input type="text" name="region" value="' . ( isset( $_POST['region']) ? $region : null ) . '">
    </div>
	<div>
    <label for="website">Post Code</label>
    <input type="text" name="postcode" value="' . ( isset( $_POST['postcode']) ? $postcode : null ) . '">
    </div>
	<div>
    <label for="website">Country</label>
    <input type="text" name="country" value="' . ( isset( $_POST['country']) ? $country : null ) . '">
    </div>
	
    <input type="submit" name="submit" value="Register"/>
    </form>
	</div>
    ';
}


// signup validation 

function mss_signup_validation( $username, $first_name = '', $last_name = '', $email, $password,  $website = '', $phone = '' , $address1 = '' ,$address2 = '',$city = '',$region = '',$postcode = '',$country = '' )  {
	global $reg_errors;
	$reg_errors = new WP_Error;
	// check if the required filed are filled up
	if ( empty( $username ) || empty( $password ) || empty( $email ) ) {
		$reg_errors->add('field', 'Required form field is missing');
	}
	// check if username is 6 characters wide
	if ( 6 > strlen( $username ) ) {
		$reg_errors->add( 'username_length', 'Username too short. At least 6 characters is required' );
	}
	//check if teh username already there
	if ( username_exists( $username ) )
		$reg_errors->add('user_name', 'Sorry, that username already exists!');
		
	//check if the username is valid by employing wordpress validate_username fucntion
	if ( ! validate_username( $username ) ) {
		$reg_errors->add( 'username_invalid', 'Sorry, the username you entered is not valid' );
	}	
	// check if the password if 8 characters long
	if ( 8 > strlen( $password ) ) {
        $reg_errors->add( 'password', 'Password length must be greater than 8' );
    }
	// check if the email is valid
	if ( !is_email( $email ) ) {
		$reg_errors->add( 'email_invalid', 'Email is not valid' );
	}
	// check if email already registered
	if ( email_exists( $email ) ) {
		$reg_errors->add( 'email', 'Email Already in use' );
	}
	//check to see if the website field is valid
	if ( ! empty( $website ) ) {
		if ( ! filter_var( $website, FILTER_VALIDATE_URL ) ) {
			$reg_errors->add( 'website', 'Website is not a valid URL' );
		}
	}
	
	if ( is_wp_error( $reg_errors ) ) {
 
		foreach ( $reg_errors->get_error_messages() as $error ) {
		 
			echo '<div>';
			echo '<strong>ERROR</strong>:';
			echo $error . '<br/>';
			echo '</div>';
			 
		}
 
	}

}


// complete signup 

function complete_signup() {
	
    global $reg_errors, $username, $first_name, $last_name, $email, $password, $website, $phone , $address1, $address2, $city , $region, $postcode, $country;
	global $ds_ss_load_css; 
	$ds_ss_load_css = true;
	
    if ( 1 > count( $reg_errors->get_error_messages() ) ) {
        $userdata = array(
        'user_login'    =>   $username,
        'user_email'    =>   $email,
        'user_pass'     =>   $password,
        'user_url'      =>   $website,
        'first_name'    =>   $first_name,
        'last_name'     =>   $last_name,
        
        );
		// last update same as signup time
		$updated  = '';
        $user_id = wp_insert_user( $userdata );
		update_user_meta( $user_id, 'phone', $phone );
		update_user_meta( $user_id, 'address1', $address1 );
		update_user_meta( $user_id, 'address2', $address2);
		update_user_meta( $user_id, 'city', $city );
		update_user_meta( $user_id, 'region', $region );
		update_user_meta( $user_id, 'postcode', $postcode );
		update_user_meta( $user_id, 'country', $country );
		update_user_meta( $user_id, 'updated', $updated );
		
        echo 'Registration complete. Goto <a href="' . get_site_url() . '/wp-login.php">login page</a>.';   
    }
}

function mss_signup_callback() { 
	if ( isset($_POST['submit'] ) ) {
	
	//	$username, $first_name = '', $last_name = '', $email, $password,  $website = '', $phone = '' , $address1 = '' ,$address2 = '',$city = '',$region = '',$postcode = '',$country = ''
		
        mss_signup_validation(
        $_POST['username'],
		$_POST['fname'],
		$_POST['lname'],
		$_POST['email'],
        $_POST['password'],
        $_POST['website']
       
        );
         
        // sanitize user form input
        global $username, $password, $email, $website, $first_name, $last_name, $nickname, $bio,$phone,$address1,$address2,$city,$region,$postcode,$country;
        $username   =   sanitize_user( $_POST['username'] );
        $password   =   esc_attr( $_POST['password'] );
        $email      =   sanitize_email( $_POST['email'] );
        $website    =   esc_url( $_POST['website'] );
        $first_name =   sanitize_text_field( $_POST['fname'] );
        $last_name  =   sanitize_text_field( $_POST['lname'] );
		$phone      = sanitize_text_field( $_POST['phone'] );
		$address1   = sanitize_text_field( $_POST['address1'] );
		$address2   = sanitize_text_field( $_POST['address2'] );
		$city 		= sanitize_text_field( $_POST['city'] ); 
		$region     = sanitize_text_field( $_POST['region'] );
		$postcode   = sanitize_text_field( $_POST['postcode'] );
		$country    = sanitize_text_field( $_POST['country'] );
        // $nickname   =   sanitize_text_field( $_POST['nickname'] );
        // $bio        =   esc_textarea( $_POST['bio'] );
 
        // call @function complete_registration to create the user
        // only when no WP_error is found
        complete_signup(
        $username,
		$first_name,
        $last_name,
		$email,
        $password,
        $website     
        );
    }
 
    mss_signup(
        $username,
		$first_name,
        $last_name,
		$email,
        $password,
        $website,
        $phone, 
		$address1,
		$address2,
		$city,
		$region,
		$postcode,
		$country  
       );

}

// Register a new shortcode: [mss_signup]
add_shortcode( 'mss_signup', 'mss_signup_shortcode' );
 
// The callback function that will replace [mss_signup]
function mss_signup_shortcode() {
    ob_start();
    mss_signup_callback();
    return ob_get_clean();
}

// differet call back functions 


function mss_top_menu() {

	$current_user = new WP_User('1');
	echo '<pre />';
	print_r($current_user);
	exit;
	
}

function add_new_mss_projects() {}
function get_merchant_transaction() {}
function get_mss_projects() {}
function get_mss_reports() {}

function add_seo_packages() {
	if (!current_user_can('add_projects'))
	{
	  wp_die( __('You do not have sufficient permissions to access this page.') );
	}
	global $wpdb;
	$project_table_name  = $wpdb->prefix.'projects';
	$table_name  = $wpdb->prefix.'seo_packages';
	if(isset($_POST['submit_package'])) {
		//Read their posted value submitted from  forn
		//$ss_project_id 				= ucwords($_POST['ss_project_id']);
		$ss_project_id  = 0; 		// hardcoded just for now
		$ss_package_name 			= ucwords($_POST['ss_package_name']);
		//$ss_package_slug 			= get_slug($_POST['ss_package_name']);
		
		$ss_package_desc 			= $_POST['ss_package_desc'];
		$ss_package_price  			= $_POST['ss_package_price'];
		$ss_package_duration	    = $_POST['ss_package_duration'];
		$ss_package_status	    	= $_POST['ss_package_status'];
		$cur_datetime       		= date('Y-m-d H:i:s'); 
		$updated_datetime   		= date('Y-m-d H:i:s'); 
		$user_id = get_current_user_id();
		if($_POST['action'] == 'save') {
			$program_count = $wpdb->get_var('SELECT COUNT(*) '.$table_name.' WHERE name = "'.$ss_package_name.'"');
			if($program_count) {
			
			}else {
				
				//$cur_date     = date('Y-m-d'); 
				$rst_cnt = $wpdb->insert($table_name, 
					array(
					'user_id' 			=> $user_id,
					'project_id'        => $ss_project_id,
					'package_name' 		=> $ss_package_name,
					'description' 		=> $ss_package_desc,
					'price' 	    	=> $ss_package_price,
					'duration' 	    	=> $ss_package_duration,
					'status' 			=> $ss_package_status,
					'created' 			=> $cur_datetimecur_datetime,
					'updated' 			=> $cur_datetime
					),
					array(
						'%d',
						'%d',
						'%s',
						'%s',
						'%d',
						'%d',
						'%d',
						'%s',
						'%s'
					)
						
				);
				
				if(false  !== $rst_cnt) { ?>
					<div class="updated"><p><strong><?php _e('Package Added Successfully.', 'menu-test' ); ?></strong></p></div>
					
				<?php	
					
					unset($ss_project_id);
					unset($ss_package_name);
					unset($ss_package_desc);
					unset($ss_package_price);
					unset($ss_package_duration);	
					unset($ss_package_status);
					//unset($ss_package_duration);
					//unset($ss_package_duration);
				}else {
					// display error 
					
				}				
					
					
			
			}
	
		}else if($_POST['action'] == 'update') {
			$key = $_GET['key'];
			$rst = $wpdb->update( 
				$table_name, 
				array(
					'user_id'       	=> $user_id,
					'project_id'        => $ss_project_id,
					'package_name' 		=> $ss_package_name,
					'description' 		=> $ss_package_desc,
					'price' 	    	=> $ss_package_price,
					'duration' 	    	=> $ss_package_duration,
					'status' 			=> $ss_package_status,
					'updated' 	        => $cur_datetime,
				), 
				array( 'package_id' => $key ), 
				array(
					'%d',
					'%d',
					'%s',	// value1
					'%s',	// value2
					'%d',
					'%d',
					'%d',
					'%s'
				), 
				array( '%d' ) 
			);	
			
			if(false  !== $rst) { ?>
				<div class="updated"><p><strong><?php _e('Package Updated Successfully.', 'menu-test' ); ?></strong></p></div>
			<?php }

		}	
	
	}
	
	include_once('inc/ds_ss_list_package_template_tpl.php');
	include_once('inc/ds_ss_package_template_tpl.php');
	echo $content;

}

function add_seo_projects() {
	
	// echo 'Add SEO projects';
	// exit;
	if (!current_user_can('add_projects'))
	{
	  wp_die( __('You do not have sufficient permissions to access this page.') );
	}
	global $wpdb;
	$table_name  = $wpdb->prefix.'projects';
	// $lfp_program_name = '';
	// $lfp_program_status = '';
	// $user_notes = '';
	$program_type = 'p';
	if(isset($_POST['submit_project'])) {
		//Read their posted value submitted from  forn
		$ss_project_name 	= ucwords($_POST['ss_project_name']);
		//$ss_project_slug 	= get_slug($_POST['ss_project_name']);
		$ss_company_name 	= ucwords($_POST['ss_company_name']);
		$ss_project_url 	= $_POST['ss_project_url'];
		$ss_project_status  = $_POST['ss_project_status'];
		$ss_description	    = $_POST['ss_description'];
		$cur_datetime       = date('Y-m-d H:i:s'); 
		$updated_datetime   = date('Y-m-d H:i:s'); 
		$user_id = get_current_user_id();
		if($_POST['action'] == 'save') {
			$program_count = $wpdb->get_var('SELECT COUNT(*) '.$table_name.' WHERE name = "'.$ss_project_name.'"');
			if($program_count) {
			
			}else {
				
				//$cur_date     = date('Y-m-d'); 
				$rst_cnt = $wpdb->insert($table_name, 
					array(
					'user_id' 			=> $user_id,
					'project_name' 		=> $ss_project_name,
					'company_name' 		=> $ss_company_name,
					'project_url' 	    => $ss_project_url,
					'description' 	    => $ss_description,
					'project_status' 	=> $ss_project_status,
					'created' 			=> $cur_datetime,
					'updated' 			=> $cur_datetime
					),
					array(
						'%d',
						'%s',
						'%s',
						'%s',
						'%s',
						'%d',
						'%s',
						'%s'
					)
						
				);
				
				if(false  !== $rst_cnt) { ?>
					<div class="updated"><p><strong><?php _e('Project Added Successfully.', 'menu-test' ); ?></strong></p></div>
					
				<?php	
					
					unset($ss_project_name);
					unset($ss_company_name);
					unset($ss_project_url);
					unset($ss_description);
					unset($ss_project_status);	
				}else {
					// display error 
					
				}				
					
					
			
			}
	
		}else if($_POST['action'] == 'update') {
			$key = $_GET['key'];
			$rst = $wpdb->update( 
				$table_name, 
				array(
					'user_id'        => $user_id,
					'project_name'   => $ss_project_name,
					'company_name'   => $ss_company_name,
					'project_url' 	 => $ss_project_url,
					'description' 	 => $ss_description,
					'project_status' => $ss_project_status,
					'updated' 	     => $cur_datetime,
				), 
				array( 'project_id' => $key ), 
				array(
					'%d',
					'%s',	// value1
					'%s',	// value2
					'%s',
					'%s',
					'%d',
					'%s'
				), 
				array( '%d' ) 
			);	
			
			if(false  !== $rst) { ?>
				<div class="updated"><p><strong><?php _e('Project Updated Successfully.', 'menu-test' ); ?></strong></p></div>
			<?php }

		}	
	
	}
	
	include_once('inc/ds_ss_list_projects_template_tpl.php');
	include_once('inc/ds_ss_project_template_tpl.php');
	echo $content;


}


function add_seo_workers() {
	global $reg_errors;
	$content = '';
	if ( isset($_POST['addworker'] ) ) {
			
		$user_login = sanitize_user( $_POST['user_login'] );
		$email      = sanitize_email( $_POST['email'] );
		$first_name = sanitize_text_field( $_POST['first_name'] );
		$last_name  = sanitize_text_field( $_POST['last_name'] );
		$pass1 	    = esc_attr( $_POST['pass1'] );
		$role       = esc_attr( $_POST['role'] );
		$current_parent = get_current_user_id();
		//$pass1 = $_POST['pass1'];
		
		mss_signup_validation(
			$user_login,
			$first_name,
			$last_name,
			$email,
			$pass1 
			      
        );
		if ( 1 > count( $reg_errors->get_error_messages() ) ) {
			$userdata = array(
				'user_login'    =>   $user_login,
				'user_email'    =>   $email,
				'user_pass'     =>   $pass1,
				'user_url'      =>   '',
				'first_name'    =>   $first_name,
				'last_name'     =>   $last_name,
				
			);
			// last update same as signup time
		
			$user_id = wp_insert_user( $userdata );
			$user = new WP_User( $user_id );
			$user->set_role( $role );
			
			//update_user_meta( $user_id, 'phone', $phone );
			
			update_user_meta( $user_id, 'parent_id', $current_parent );
			
			//update_user_meta( $user_id, 'address1', $address1 );

			//echo 'Registration complete. Goto <a href="' . get_site_url() . '/wp-login.php">login page</a>.';   
		}
	
	}
	include_once('inc/ds_ss_add_seo_workers_tpl.php');
	include_once('inc/ds_ss_list_seo_workers_tpl.php');
	//include_once('inc/ds_ss_add_seo_workers_tpl.php');
	echo $content;
	// $data = get_userdata( get_current_user_id() );
 
	// if ( is_object( $data) ) {
		// $current_user_caps = $data->allcaps;
		//print it to the screen
		// echo '<pre>' . print_r( $current_user_caps, true ) . '</pre>';
	// }	
		



}

function list_seo_workers() {
	//
	


}

// Assing SEO workers
function assign_seo_workers() {
	//

}


//Add merchant Different Menus
function ds_seoservices_menusetup(){
	// Remove duplicate submenu name for top menu item : http://wordpress.stackexchange.com/questions/200144/how-to-remove-duplicate-sub-menu-name-for-top-level-menu-items-in-a-plugin
	
	add_menu_page( 'Merchants', 'Merchants', 'merchant', 'merchant_menu', 'mss_top_menu' );
	//add_submenu_page('merchant_menu', 'Add Project', 'Add New Project', 'ssng_projects','mss_new_project', 'add_new_mss_projects');
	add_submenu_page('merchant_menu', 'Projects', 'Projects', 'ssng_projects','merchant_menu', 'mss_top_menu');
	#add_submenu_page('merchant_menu', 'Projects', 'Projects', 'ssng_projects','mss_projects', 'get_mss_projects');
	add_submenu_page('merchant_menu', 'Transaction', 'Transaction', 'ssng_transaction','mss_transaction', 'get_merchant_transaction');
	add_submenu_page('merchant_menu', 'Reports', 'Reports', 'ssng_reports','mss_reports', 'get_mss_reports');
		
	add_menu_page( 'Seo Partner', 'Seo Partner Manager', 'seo_manager', 'seo_manager_menu', 'mss_smp_menu' );
	add_submenu_page('seo_manager_menu', 'Add Worker', 'Add SEO Worker', 'add_worker','add_worker','add_seo_workers');
	add_submenu_page('seo_manager_menu', 'Assign Work', 'Assign SEO Work', 'assign_seo_work','assign_seo_work', 'assign_seo_workers');
	add_submenu_page('seo_manager_menu', 'Invoices Details', 'Invoices Details', 'see_invoices','see_invoices', 'get_invoices_details');
	
	// For administrator only 
	add_submenu_page('seo_manager_menu', 'Add Projects', 'Add SEO Projects', 'add_projects','add_projects', 'add_seo_projects');
	add_submenu_page('seo_manager_menu', 'Add Packages', 'Add SEO Packages', 'add_seo_packages','add_seo_packages', 'add_seo_packages');
	
	//add_submenu_page('seo_manager_menu', 'Alerts On Singup', 'Alerts On Singup', 'alert_onsignup_packages','alert_onsignup_packages', 'get_mss_');
	//add_submenu_page('seo_manager_menu', 'Delayed Reports', 'Delayed Reports Alert', 'alert_for_delayed_reports','alert_for_delayed_reports', 'get_mss_projects');
	add_menu_page( 'Seo Worker', 'Seo Partner Worker', 'seo_worker', 'seo_worker_menu', 'mss_swp_menu' );
	add_submenu_page('seo_worker_menu', 'Add Reports', 'Add Weekly Reports', 'add_weekly_reports','add_weekly_reports', 'add_reports');
	add_submenu_page('seo_worker_menu', 'Add Keywords', 'Add Keywords', 'add_keywords','add_keywords', 'add_keywords');
	
}


//  Add Custom Capabilities 


function add_custom_capabilities() {

	


}

/* Add Custom Site Specific Roles and Capabilities */


function ds_ss_custom_role() {
	remove_role('merchant');
	remove_role('seo_manager');
	remove_role('seo_worker');
	//add_custom_capabilities(); // as the capablities for while suing add_role not being assigned to user role correctaly
	$merchant = add_role( 'merchant', 'Merchant', array(
	'read' => true, /* Allow access to administrator panel, User Profile */ 
	'ssng_transaction',
	'ssng_reports',
	'ssng_projects'
	));
	
	//  Seo Manager 
	$seo_manager = add_role( 'seo_manager', 'Seo Manager', array(
	'read' => true, /* Allow access to administrator panel, User Profile */
    'add_users'	=> true,
	'create_users' => true,
	'add_worker',
	'assign_seo_work',
	'see_invoices',
	'alert_onsignup_packages',
	'alert_for_delayed_reports'
	));
	
	//Seo Worker 
	$seo_worker = add_role( 'seo_worker', 'Seo Worker', array(
	'read' => true, /* Allow access to administrator panel, User Profile */ 
	'add_weekly_reports',
	'add_keywords'
	
	));
	
	
	global $wp_roles;
	$role = get_role( 'administrator' );
	if( null !== $merchant ) {
	
		$wp_roles->add_cap( 'merchant', 'ssng_reports' );
		$wp_roles->add_cap( 'merchant', 'ssng_transaction' );
		$wp_roles->add_cap( 'merchant', 'ssng_projects' );
		
		//$role = get_role( 'administrator' );
		/* Any custom capabilities must be added to administrator too always */
		//$role->add_cap('merchant');
		$role->add_cap('ssng_reports');
		$role->add_cap('ssng_transaction');
		$role->add_cap('ssng_reports');
		$role->add_cap('ssng_projects');
	}
	
	if( null !== $seo_manager ) {

		$wp_roles->add_cap( 'seo_manager', 'add_worker' );
		$wp_roles->add_cap( 'seo_manager', 'assign_seo_work' );
		$wp_roles->add_cap( 'seo_manager', 'see_invoices' );
		$wp_roles->add_cap( 'seo_manager', 'alert_onsignup_packages' );
		$wp_roles->add_cap( 'seo_manager', 'alert_for_delayed_reports' );
		
		//$seomanager_role = get_role( 'seo_manager' );
		/* Any custom capabilities must be added to administrator too always */
		// $role->add_cap('merchant');
		$role->add_cap('add_worker');
		$role->add_cap('assign_seo_work');
		$role->add_cap('see_invoices');
		$role->add_cap('alert_onsignup_packages');
		$role->add_cap('alert_for_delayed_reports');
		//$seomanager_role->add_cap();
	
	}
	
	
	if( null !== $seo_worker ) {

		$wp_roles->add_cap( 'seo_worker', 'add_weekly_reports' );
		$wp_roles->add_cap( 'seo_worker', 'add_keywords' );

		
		/* Any custom capabilities must be added to administrator too always */
		//$role->add_cap('merchant');
		$role->add_cap('add_weekly_reports');
		$role->add_cap('add_keywords');

	}
	
	// More custom capablities for administrator
	$role->add_cap('add_projects');
	$role->add_cap('add_seo_packages');

}

function ds_ss_add_styles() {
	wp_register_style('ds_ss_frms_style',plugins_url('css/ds_ss_frms_styles.css',__FILE__));
}

function ds_ss_print_css() {
	global $ds_ss_load_css; 
	// $ds_ss_load_css = true;;
	//this variable is set to TRUE if the short code is used on a page/post
	if ( ! $ds_ss_load_css )
		return; // this means that neither short code is present, so we get out of here
 	wp_print_styles('ds_ss_frms_style');

}

add_action( 'init', 'ds_ss_add_styles' );	
add_action('wp_footer', 'ds_ss_print_css');
add_action( 'admin_init', 'ds_ss_custom_role' );
add_action('admin_menu', 'ds_seoservices_menusetup');

?>