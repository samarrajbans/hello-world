<?php

	$content .= '<div class="wrap">
	<div id="icon-tools" class="icon32"></div>
	<p> <a href="?page=add_projects" class="" >Add New Project </a></p>
	';
	if(isset($_GET['action']) &&( $_GET['action'] == 'edit')){
		$content .= '<h2>Edit Project </h2>';
	}else {
		$content .= '<h2>Add Project </h2>';
	}
	$content .= '<form method="post" >
		
		<table class="form-table">
			<tbody>
				<tr valign="top">';
					if(isset($_GET['action']) == 'edit'){
					$content .= '<th scope="row">
						<label for="ss_project_name">Project Name</label></th>
						<td><input type="text" class="regular-text" value="'.$ss_project_name.'" id="ss_project_name" name="ss_project_name" readonly= "readonly" />';
				}else
				$content .= '<th scope="row"><label for="ss_project_name">Add Project</label></th>
					<td><input type="text" class="regular-text" value="'.$ss_project_name.'" id="ss_project_name" name="ss_project_name"/>';
				
				$content .= '</tr>
				
				<tr valign="top">
					<th scope="row"><label for="ss_project_status">Program Status</label></th>
					<td>
					<select name="ss_project_status" id="ss_project_status" >
						<option value="1" '.( $ss_project_status == "1"?"selected=selected":"").'>Enable</option>
						<option value="0" '.( $ss_project_status == "0"?"selected=selected":"").'>Disable</option>
					</select>
					<p class="description">Make project active/deactive</p></td>
				</tr>
				<tr valign="top">
					<th scope="row"><label for="ss_company_name">Project Company Name</label></th>
					<td>
					<input type="text" class="regular-text" value="'.$ss_company_name.'" id="ss_company_name" name="ss_company_name"/>
					<p class="description"></p></td>
				</tr>
				<tr valign="top">
					<th scope="row"><label for="ss_project_url">Project URL</label></th>
					<td>
					<input type="text" class="regular-text" value="'.$ss_project_url.'" id="ss_project_url" name="ss_project_url" />
					<p class="description"></p></td>
				</tr>';
				
				$content .='<tr valign="top">
					<th scope="row"><label for="ss_description">User Notes/Description</label></th>
					<td><textarea cols="40" name="ss_description" id="ss_description">'.$ss_description.'</textarea></td>
				</tr>
		
			</tbody>
		</table>';
	$submit_btn_value = (isset($_GET["action"]) && ($_GET["action"] == 'edit'))? 'update' : 'save';
	
    $content .= '<p class="submit"><input type="hidden" name="action" value="'.$submit_btn_value.'" /><input type="submit" value="'.ucfirst($submit_btn_value).'" class="button-primary" id="ss_project_btn" name="submit_project" /></p>';
    
	$content .= '</form></div>';

?>