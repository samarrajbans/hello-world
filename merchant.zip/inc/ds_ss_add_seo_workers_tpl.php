<?php 
	$content .='<div class="wrap">
		<h2 id="add-new-user"> Add SEO Worker</h2>
		<form action="' . $_SERVER['REQUEST_URI'] . '" method="post">
		<table class="form-table" style="width:600px;">
			<tbody>
				<tr class="form-field form-required">
					<th scope="row">
						<label for="user_login">Username <span class="description">(required)</span></label>
					</th>
					<td><input name="user_login" type="text" id="user_login" value="" aria-required="true"></td>
				</tr>
				<tr class="form-field form-required">
					<th scope="row"><label for="email">E-mail <span class="description">(required)</span></label></th>
					<td><input name="email" type="email" id="email" value=""></td>
				</tr>
				<tr class="form-field">
					<th scope="row"><label for="first_name">First Name </label></th>
					<td><input name="first_name" type="text" id="first_name" value=""></td>
				</tr>
				<tr class="form-field">
					<th scope="row"><label for="last_name">Last Name </label></th>
					<td><input name="last_name" type="text" id="last_name" value=""></td>
				</tr>
				<tr class="form-field form-required">
					<th scope="row"><label for="pass1">Password <span class="description">(required)</span></label></th>
					<td><input name="pass1" type="password" id="pass1" autocomplete="off"></td>
				</tr>
				<tr class="form-field">
					<th scope="row"><label for="role">Role</label></th>
						<td>
							<select name="role" id="role">
								<option selected="selected" value="seo_worker">Seo Worker</option>
							</select>
						</td>
				</tr>
				
			</tbody>
		</table>
    
		<p class="submit">
			<input type="submit" name="addworker" id="addworker" class="button button-primary" value="Add Worker" /></p>
	
		</form>
	</div>
	';
	
?>