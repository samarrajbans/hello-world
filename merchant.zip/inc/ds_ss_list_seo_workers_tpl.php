<?php
	
	$current_parent = get_current_user_id();
	// $args = array(  
        // 'meta_key'     => 'parent_id',
        // 'meta_value'   => $current_parent,
    // ) 
	if($current_parent == 1 ) {
		$args = array(
			'role'         => 'seo_worker'
		); 
		
	}else {
		$args = array(
			'role'         => 'seo_worker',
			'meta_query'   => array(
				'relation' => 'AND',
				array( 
					'key'     => 'parent_id',
					'value'   => array( $current_parent,1 ),
					'compare' => 'IN'
				)
			),
		); 
	}
	//$allseoworkers = get_users( 'role=seo_worker&parent_id='.$current_parent );
	
	
	$user_query = get_users( $args );;
	// echo '<pre />';
	// print_r($user_query);
	// exit;
	
	if( count( $user_query) ) { 
		
		$content .='<div class="wrap">
			<div id="icon-tools" class="icon32"></div>
			<h2>All SEO Workers</h2>
			<table class="widefat fixed">
			<tbody>
				<tr>
					<th>Username</th>
					<th>Name</th>
					<th>Email</th>
					<th>Role</th>
					<th>Parent</th>
				</tr>';	
			foreach($user_query as $user){
				$name        =  get_usermeta($user->ID,'first_name',true);
				//$role        = get_usermeta($user->ID,'wp_capabilities',true);
				$parent_id   = get_usermeta($user->ID,'parent_id',true);
				$parent_name = get_usermeta($parent_id,'first_name',true);
				$parent_role  = new WP_User( $parent_id );
				$content .='<tr>
					<td>'.$user->user_login.'</td>
					<td>'.$name.'</td>
					<td>'.$user->user_email.'</td>
					<td>'.$user->roles[0].'</td>
					<td>'.$parent_name.'( '.$parent_role->roles[0].' )'.'</td>
				</tr>';	
		} 
		
	$content .='</tbody>
	</table>
		
	</div>';
		

	}else {
		
		$content .='<div class="wrap"><h2>Sorry No user being added yet! </h2></div>';
		
		
	
	}



?>