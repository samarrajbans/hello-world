<?php


if(isset($_GET['action'])){

	if($_GET['action'] == 'delete') {
		$rec_id =  $_GET['key'];
		//echo 'table name:'.$table_name;exit;
		$rst = $wpdb->delete( $table_name, array( 'package_id' => $rec_id ), array( '%d' ) );
			if(false !== $rst) {		
			echo 'Package Deleted Successfully.';
			} else{
				echo 'Error...';
			}

	}else if($_GET['action'] == 'edit'){
		$key = $_GET['key'];
		
		$rsts = $wpdb->get_row('SELECT * FROM '.$table_name.' WHERE package_id  = '.$key, OBJECT );
		$ss_package_name	  =   $rsts->package_name ;	 
		$ss_package_desc      =   $rsts->description ;	 
		$ss_package_price     =   $rsts->price; 
		$ss_package_duration  =   $rsts->duration;	 
		$ss_package_status    =   $rsts->status ;
		$cur_datetime         =   $rsts->updated ;		 
		//$_datetime          =   $rsts->updated ; 	
		
		//echo $int_program_reg_start = $cur_prog['int_program_reg_start'];
		//echo $int_program_reg_ends = $cur_prog['int_program_reg_ends'];
	}
}

$rsts = $wpdb->get_results( 'SELECT * FROM '.$table_name, OBJECT );				
if(count($rsts)) {
?>
<div class="wrap">
	<div id="icon-tools" class="icon32"></div>
	<h2>All Packages</h2>
		<table class="widefat fixed">
		<tbody>
			<tr>
				<th>Package Name</th>
				<th>Desciption</th>
				<th>Price</th>
				<th>Duration</th>
				<th>Status</th>
				<th>Last Updated</th>
				<th>Action</th>		
			</tr>	
			<?php
		
			
			foreach($rsts as $rst){
			 ?>
			<tr>
			<td><?php echo  $rst->package_name; ?></td>
			<td><?php echo  $rst->description; ?></td>
			<td><?php echo  $rst->price; ?></td>
			<td><?php echo  $rst->duration; ?></td>
			<td><?php echo  (($rst->status == 1)?'Enable':'Disable') ; ?></td>
			<td><?php echo  $rst->updated  ; ?></td>
			<td><a href="?page=add_seo_packages&action=edit&key=<?php echo $rst->package_id ;?>">edit</a>&nbsp;<a href="?page=add_seo_packages&action=delete&key=<?php echo $rst->package_id ;?>">delete</a></td>
			
		<?php } ?>
		</tr>
	</tbody>
	</table>
		
	</div>
	
<?php

	}

?>