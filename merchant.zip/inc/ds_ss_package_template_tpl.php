	<?php
	
	//project_table_name
	
	// $rsts = $wpdb->get_results( 'SELECT * FROM '.$project_table_name.' WHERE project_status  = 1', OBJECT );
	// $project_lists = '';
	// if(count($rsts)>0) {
		// $project_lists .='<select name="ss_project_id">';
		// foreach($rsts as $rst){
			// $project_lists .= '<option value="'.$rst->project_id.'">'.$rst->project_name.'</option>';
		// }
		// $project_lists .='</select>';
	// }else {
		// $project_lists .='<select name="ss_project_id">
		
			// <option value="0">-NA-</option>
		
		// </select>';
	// }
	
	$content .= '<div class="wrap">
	<div id="icon-tools" class="icon32"></div>
	<p> <a href="?page=add_seo_packages" class="" >Add/Assign Packages </a></p>
	';
	if(isset($_GET['action']) &&( $_GET['action'] == 'edit')){
		$content .= '<h2>Edit Package>';
	}else {
		$content .= '<h2>Add Package </h2>';
	}
	$content .= '<form method="post" >
		
		<table class="form-table">
			<tbody>
				<tr valign="top">';
					if(isset($_GET['action']) == 'edit'){
					$content .= '<th scope="row">
						<label for="ss_package_name">Package Name</label></th>
						<td><input type="text" class="regular-text" value="'.$ss_package_name.'" id="ss_package_name" name="ss_package_name" readonly= "readonly" />';
				}else
				$content .= '<th scope="row"><label for="ss_package_name">Add Package</label></th>
					<td><input type="text" class="regular-text" value="'.$ss_package_name.'" id="ss_package_name" name="ss_package_name"/>';
				
				$content .= '</tr>
				
				<tr valign="top">
					<th scope="row"><label for="ss_package_status">Package Status</label></th>
					<td>
					<select name="ss_package_status" id="ss_package_status" >
						<option value="1" '.( $ss_package_status == "1"?"selected=selected":"").'>Enable</option>
						<option value="0" '.( $ss_package_status == "0"?"selected=selected":"").'>Disable</option>
					</select>
					<p class="description">Make Package active/deactive</p></td>
				</tr>
				<tr valign="top">
					<th scope="row"><label for="ss_package_desc">User Notes/Description</label></th>
					<td><textarea cols="40" name="ss_package_desc" id="ss_package_desc">'.$ss_package_desc.'</textarea></td>
				</tr>
				<tr valign="top">
					<th scope="row"><label for="ss_package_price">Price</label></th>
					<td>
					<input type="text" class="regular-text" value="'.$ss_package_price.'" id="ss_package_price" name="ss_package_price"/>
					<p class="description"></p></td>
				</tr>
				<tr valign="top">
					<th scope="row"><label for="ss_package_duration">Duration</label></th>
					<td>
					<input type="text" class="regular-text" value="'.$ss_package_duration.'" id="ss_package_duration" name="ss_package_duration" />
					<p class="description"></p></td>
				</tr>
		
			</tbody>
		</table>';
	$submit_btn_value = (isset($_GET["action"]) && ($_GET["action"] == 'edit'))? 'update' : 'save';
	
    $content .= '<p class="submit"><input type="hidden" name="action" value="'.$submit_btn_value.'" /><input type="submit" value="'.ucfirst($submit_btn_value).'" class="button-primary" id="ss_package_btn" name="submit_package" /></p>';
    
	$content .= '</form></div>';

?>